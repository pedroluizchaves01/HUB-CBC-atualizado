import React, { useState, useEffect, useRef } from 'react';
import { 
  TrendingUp, 
  Plus, 
  Trash2, 
  FileText, 
  Loader2, 
  Paperclip, 
  ExternalLink, 
  Folder, 
  Sparkles, 
  Upload, 
  CheckCircle2, 
  AlertCircle,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Camera,
  X
} from 'lucide-react';
import { Transaction, TransactionCategory, Project } from '../types';
import { initAuth, googleSignIn, logoutGoogle, manualGoogleSignIn } from '../lib/firebaseAuth';
import { findOrCreateFolder, uploadFileToFolder } from '../lib/googleDrive';
import { User as FirebaseUser } from 'firebase/auth';

interface AcompanhamentoFinanceiroProps {
  projectId: string;
  project: Project | undefined;
  transactions: Transaction[];
  addTransaction: (tx: Transaction) => void;
  deleteTransaction: (id: string) => void;
}

export default function AcompanhamentoFinanceiro({
  projectId,
  project,
  transactions,
  addTransaction,
  deleteTransaction,
}: AcompanhamentoFinanceiroProps) {
  // Auth state
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Manual Google Connection Form state
  const [showManualLogin, setShowManualLogin] = useState(false);
  const [manualEmail, setManualEmail] = useState('');
  const [manualPassword, setManualPassword] = useState('');
  const [manualFolder, setManualFolder] = useState('');

  // Update manual folder name when project loads
  useEffect(() => {
    if (project) {
      setManualFolder(`Chaves Brites - Notas Fiscais - ${project.name}`);
    }
  }, [project]);

  const handleManualLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualEmail.trim()) {
      alert('Por favor, informe o e-mail da conta do Google Drive.');
      return;
    }
    setIsLoggingIn(true);
    try {
      const { user: u, accessToken: t } = await manualGoogleSignIn(
        manualEmail.trim(),
        manualFolder.trim() || `Chaves Brites - Notas Fiscais - ${project?.name || ''}`
      );
      setUser(u);
      setAccessToken(t);
      setShowManualLogin(false);
      alert('Autenticado com sucesso via dados da conta Google Drive!');
    } catch (err) {
      console.error('Erro ao conectar manualmente:', err);
      alert('Falha ao conectar.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Panel state
  const [isCollapsed, setIsCollapsed] = useState(false);

  // Folder state
  const [folderId, setFolderId] = useState<string | null>(null);
  const [isResolvingFolder, setIsResolvingFolder] = useState(false);

  // Form states
  const [isManualFormOpen, setIsManualFormOpen] = useState(false);
  const [manualForm, setManualForm] = useState({
    supplier: '',
    description: '',
    value: '',
    category: 'materiais' as TransactionCategory,
    date: new Date().toISOString().split('T')[0],
    notes: '',
    invoiceNumber: '',
  });

  // AI Invoice states
  const [selectedFile, setSelectedFile] = useState<{ name: string; type: string; base64: string } | null>(null);
  const [isParsing, setIsParsing] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  
  // Scanned / Preview invoice data
  const [scannedData, setScannedData] = useState<{
    supplier: string;
    date: string;
    value: number;
    category: TransactionCategory;
    description: string;
    notes: string;
    invoiceNumber: string;
  } | null>(null);

  // File upload state for Google Drive upload
  const [isUploadingToDrive, setIsUploadingToDrive] = useState(false);
  const [saveToDriveChecked, setSaveToDriveChecked] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraFileInputRef = useRef<HTMLInputElement>(null);

  // Camera states
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // AI Bulk states & tabs
  const [activeTab, setActiveTab] = useState<'single' | 'bulk'>('single');
  const [bulkFile, setBulkFile] = useState<{ name: string; type: string; base64: string } | null>(null);
  const [isBulkParsing, setIsBulkParsing] = useState(false);
  const [bulkError, setBulkError] = useState<string | null>(null);
  const [bulkTransactions, setBulkTransactions] = useState<{
    supplier: string;
    description: string;
    value: number;
    category: TransactionCategory;
    date: string;
    notes?: string;
    invoiceNumber?: string;
    selected?: boolean;
  }[] | null>(null);

  const bulkFileInputRef = useRef<HTMLInputElement>(null);

  const handleBulkFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processBulkFile(file);
  };

  const processBulkFile = (file: File) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      setBulkFile({
        name: file.name,
        type: file.type,
        base64: base64String,
      });
      triggerBulkParse(base64String, file.type, file.name);
    };
    reader.onerror = (error) => {
      console.error('Erro na leitura do arquivo em lote:', error);
      setBulkError('Erro ao carregar o arquivo localmente.');
    };
  };

  const triggerBulkParse = async (base64: string, mimeType: string, name: string) => {
    setIsBulkParsing(true);
    setBulkError(null);
    setBulkTransactions(null);

    try {
      const cleanBase64 = base64.includes(';base64,') ? base64.split(';base64,')[1] : base64;
      
      const res = await fetch('/api/acompanhamento/parse-bulk-transactions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileBase64: cleanBase64,
          mimeType,
          fileName: name,
        }),
      });

      if (!res.ok) {
        throw new Error('Falha no servidor ao analisar a planilha/PDF de gastos.');
      }

      const responseData = await res.json();
      if (responseData.success && responseData.transactions) {
        setBulkTransactions(
          responseData.transactions.map((t: any) => ({
            supplier: t.supplier || 'Diverso/Não Identificado',
            description: t.description || 'Gasto importado',
            value: parseFloat(t.value) || 0,
            category: (['materiais', 'mao_de_obra', 'projetos_complementares', 'taxas', 'decoracao', 'outros'].includes(t.category)
              ? t.category
              : 'outros') as TransactionCategory,
            date: t.date || new Date().toISOString().split('T')[0],
            notes: t.notes || '',
            invoiceNumber: t.invoiceNumber || '',
            selected: true,
          }))
        );
      } else {
        throw new Error(responseData.error || 'Nenhum lançamento foi encontrado ou extraído.');
      }
    } catch (err: any) {
      console.error('Erro ao analisar em lote com IA:', err);
      setBulkError(err.message || 'Erro de processamento com Inteligência Artificial.');
    } finally {
      setIsBulkParsing(false);
    }
  };

  const handleSaveBulkTransactions = () => {
    if (!bulkTransactions) return;
    
    const selectedTxs = bulkTransactions.filter(t => t.selected);
    if (selectedTxs.length === 0) {
      alert('Nenhum lançamento selecionado para importação.');
      return;
    }

    selectedTxs.forEach((t, index) => {
      const newTx: Transaction = {
        id: `tx-${Date.now()}-${index}`,
        projectId,
        supplier: t.supplier,
        description: t.description,
        value: t.value,
        category: t.category,
        date: t.date,
        status: 'pago',
        notes: t.notes ? t.notes.trim() : undefined,
        invoiceNumber: t.invoiceNumber ? t.invoiceNumber.trim() : undefined,
      };
      addTransaction(newTx);
    });

    setBulkFile(null);
    setBulkTransactions(null);
    setBulkError(null);
    if (bulkFileInputRef.current) {
      bulkFileInputRef.current.value = '';
    }
    alert(`${selectedTxs.length} lançamentos financeiros importados com sucesso!`);
  };

  const handleCancelBulk = () => {
    setBulkFile(null);
    setBulkTransactions(null);
    setBulkError(null);
    if (bulkFileInputRef.current) {
      bulkFileInputRef.current.value = '';
    }
  };

  // Camera control and cleanup
  const startCamera = async () => {
    setIsCameraActive(true);
    setCameraError(null);
    setCameraStream(null);

    // Give state some time to render the video element if needed
    setTimeout(async () => {
      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('Acesso à câmera não é suportado pelo seu navegador atual. Use o botão de câmera nativa do celular abaixo.');
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
        });

        setCameraStream(stream);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(e => {
            console.error('Erro ao dar play no vídeo:', e);
          });
        }
      } catch (err: any) {
        console.error('Erro ao abrir a câmera:', err);
        let errorMsg = 'Permissão de acesso à câmera negada ou bloqueada pelo navegador.';
        if (err.name === 'NotAllowedError') {
          errorMsg = 'Permissão de câmera negada. Por favor, ative a permissão de câmera nas configurações do navegador ou use o botão abaixo para abrir a câmera nativa.';
        } else if (err.message) {
          errorMsg = err.message;
        }
        setCameraError(errorMsg);
      }
    }, 150);
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
    }
    setCameraStream(null);
    setIsCameraActive(false);
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');
    
    if (context) {
      // Set canvas dimensions matching the video stream
      const width = video.videoWidth || 640;
      const height = video.videoHeight || 480;
      canvas.width = width;
      canvas.height = height;
      
      // Draw frame
      context.drawImage(video, 0, 0, width, height);
      
      // Extract as base64 jpeg
      const base64String = canvas.toDataURL('image/jpeg', 0.85);
      
      setSelectedFile({
        name: `foto_comprovante_${Date.now()}.jpg`,
        type: 'image/jpeg',
        base64: base64String,
      });

      // Stop camera stream
      stopCamera();

      // Trigger scanning
      triggerAiScan(base64String, 'image/jpeg', `camera_${Date.now()}.jpg`);
    }
  };

  const handleCameraFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processSelectedFile(file);
  };

  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [cameraStream]);

  // 1. Initialize Auth on Mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (firebaseUser, token) => {
        setUser(firebaseUser);
        setAccessToken(token);
      },
      () => {
        setUser(null);
        setAccessToken(null);
        setFolderId(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // 2. Resolve Project Folder when connected
  useEffect(() => {
    if (accessToken && project) {
      resolveFolder();
    } else {
      setFolderId(null);
    }
  }, [accessToken, projectId, project]);

  const resolveFolder = async () => {
    if (!accessToken || !project) return;
    setIsResolvingFolder(true);
    try {
      const cacheKey = `cbc_gd_folder_id_${projectId}`;
      const cached = localStorage.getItem(cacheKey);
      if (cached) {
        setFolderId(cached);
        setIsResolvingFolder(false);
        return;
      }

      const folderName = `Chaves Brites - Notas Fiscais - ${project.name}`;
      const id = await findOrCreateFolder(accessToken, folderName);
      localStorage.setItem(cacheKey, id);
      setFolderId(id);
    } catch (err) {
      console.error('Erro ao resolver pasta no Google Drive:', err);
    } finally {
      setIsResolvingFolder(false);
    }
  };

  const handleConnectDrive = async () => {
    setIsLoggingIn(true);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
      }
    } catch (err) {
      console.error('Falha de conexão com Google:', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleDisconnectDrive = async () => {
    if (window.confirm('Deseja desconectar sua conta do Google Drive?')) {
      await logoutGoogle();
      setUser(null);
      setAccessToken(null);
      setFolderId(null);
    }
  };

  // Helper formats
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(val);
  };

  const getCategoryBadgeColor = (cat: TransactionCategory) => {
    switch (cat) {
      case 'materiais':
        return 'bg-amber-50 text-amber-800 border-amber-200';
      case 'mao_de_obra':
        return 'bg-emerald-50 text-emerald-800 border-emerald-200';
      case 'projetos_complementares':
        return 'bg-blue-50 text-blue-800 border-blue-200';
      case 'taxas':
        return 'bg-purple-50 text-purple-800 border-purple-200';
      case 'decoracao':
        return 'bg-rose-50 text-rose-800 border-rose-200';
      default:
        return 'bg-stone-100 text-stone-700 border-stone-200';
    }
  };

  const getCategoryLabel = (cat: TransactionCategory) => {
    switch (cat) {
      case 'materiais': return 'Materiais';
      case 'mao_de_obra': return 'Mão de Obra';
      case 'projetos_complementares': return 'Projetos Compl.';
      case 'taxas': return 'Taxas/Impostos';
      case 'decoracao': return 'Decoração';
      default: return 'Outros';
    }
  };

  // Filter project transactions
  const projectTransactions = transactions
    .filter(t => t.projectId === projectId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const totalSpent = projectTransactions.reduce((acc, t) => acc + t.value, 0);

  // File Upload Handlers (for AI reading & storage)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processSelectedFile(file);
  };

  const processSelectedFile = (file: File) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64String = reader.result as string;
      setSelectedFile({
        name: file.name,
        type: file.type,
        base64: base64String,
      });
      // Automatically trigger AI scanning
      triggerAiScan(base64String, file.type, file.name);
    };
    reader.onerror = (error) => {
      console.error('Erro na leitura do arquivo:', error);
      setAiError('Erro ao carregar o arquivo localmente.');
    };
  };

  const triggerAiScan = async (base64: string, mimeType: string, name: string) => {
    setIsParsing(true);
    setAiError(null);
    setScannedData(null);

    try {
      const cleanBase64 = base64.includes(';base64,') ? base64.split(';base64,')[1] : base64;
      
      const res = await fetch('/api/acompanhamento/parse-invoice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          fileBase64: cleanBase64,
          mimeType,
          fileName: name,
        }),
      });

      if (!res.ok) {
        throw new Error('Falha no servidor ao analisar a nota fiscal.');
      }

      const responseData = await res.json();
      if (responseData.success && responseData.invoice) {
        const { supplier, date, value, category, description, notes, invoiceNumber } = responseData.invoice;
        setScannedData({
          supplier: supplier || '',
          date: date || new Date().toISOString().split('T')[0],
          value: value || 0,
          category: (category === 'mao_de_obra' || category === 'materiais' ? category : 'outros') as TransactionCategory,
          description: description || '',
          notes: notes || '',
          invoiceNumber: invoiceNumber || '',
        });
      } else {
        throw new Error(responseData.error || 'Não foi possível extrair os dados da nota.');
      }
    } catch (err: any) {
      console.error('Erro no escaneamento com IA:', err);
      setAiError(err.message || 'Houve um problema ao processar o arquivo com Inteligência Artificial.');
      // Pre-populate empty data to allow manual entry with original attachment
      setScannedData({
        supplier: '',
        date: new Date().toISOString().split('T')[0],
        value: 0,
        category: 'materiais',
        description: '',
        notes: '',
        invoiceNumber: '',
      });
    } finally {
      setIsParsing(false);
    }
  };

  // Submit Lançamento (Manual)
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualForm.supplier.trim() || !manualForm.value) return;

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      projectId,
      supplier: manualForm.supplier.trim(),
      description: manualForm.description.trim() || 'Lançamento Manual',
      value: parseFloat(manualForm.value),
      category: manualForm.category,
      date: manualForm.date,
      status: 'pago',
      notes: manualForm.notes.trim() || undefined,
      invoiceNumber: manualForm.invoiceNumber.trim() || undefined,
    };

    addTransaction(newTx);
    setManualForm({
      supplier: '',
      description: '',
      value: '',
      category: 'materiais',
      date: new Date().toISOString().split('T')[0],
      notes: '',
      invoiceNumber: '',
    });
    setIsManualFormOpen(false);
  };

  // Confirm Scanned Invoice & Save
  const handleSaveScannedInvoice = async () => {
    if (!scannedData || !selectedFile) return;

    if (!scannedData.supplier.trim()) {
      alert('Por favor, informe o Fornecedor.');
      return;
    }
    if (scannedData.value <= 0) {
      alert('Por favor, informe um valor maior que R$ 0,00.');
      return;
    }

    // Format filename as "DATA - FORNECEDOR - RESUMO DA DESCRIÇÃO - VALOR"
    const cleanString = (str: string) => str.replace(/[/\\?%*:|"<>\n\r]/g, '').trim();
    const formattedDate = scannedData.date || new Date().toISOString().split('T')[0];
    const formattedSupplier = cleanString(scannedData.supplier || 'Fornecedor Desconhecido');
    const formattedDesc = cleanString(scannedData.description || 'Nota Fiscal');
    
    // Format value as BRL currency
    const formattedValue = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(scannedData.value);
    
    const fileExtension = selectedFile.name.includes('.') ? selectedFile.name.split('.').pop() : 'pdf';
    const formattedFilename = `${formattedDate} - ${formattedSupplier} - ${formattedDesc} - ${formattedValue}.${fileExtension}`;

    let driveLink = '';
    
    // Upload to Google Drive if connected and checked
    if (user && accessToken && folderId && saveToDriveChecked) {
      setIsUploadingToDrive(true);
      try {
        const uploadResult = await uploadFileToFolder(
          accessToken,
          folderId,
          formattedFilename,
          selectedFile.type,
          selectedFile.base64
        );
        driveLink = uploadResult.webViewLink;
      } catch (err) {
        console.error('Falha ao subir arquivo para o Drive:', err);
        alert('Atenção: O gasto será lançado localmente, mas ocorreu um erro ao enviar o arquivo para o Google Drive.');
      } finally {
        setIsUploadingToDrive(false);
      }
    }

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      projectId,
      supplier: scannedData.supplier,
      description: scannedData.description || 'Lançamento automático via NF',
      value: scannedData.value,
      category: scannedData.category,
      date: scannedData.date,
      status: 'pago',
      notes: scannedData.notes || undefined,
      invoiceNumber: scannedData.invoiceNumber || undefined,
      receiptName: driveLink || 'Local: ' + formattedFilename,
      receiptBase64: selectedFile.base64, // Storing base64 content so it's always viewable/downloadable!
    };

    addTransaction(newTx);
    
    // Clear states
    setSelectedFile(null);
    setScannedData(null);
    setAiError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleCancelScanned = () => {
    setSelectedFile(null);
    setScannedData(null);
    setAiError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className={`bg-white border border-stone-200 p-6 transition-all duration-300 ${isCollapsed ? 'space-y-0 pb-4' : 'space-y-6'}`}>
      
      {/* Module Title */}
      <div className={`flex flex-col md:flex-row md:items-center md:justify-between gap-4 ${isCollapsed ? '' : 'border-b border-stone-100 pb-4'}`}>
        <div>
          <h3 className="font-serif text-base text-stone-950 font-bold flex flex-wrap items-center gap-2">
            <TrendingUp size={16} className="text-stone-700" />
            <span>Módulo Financeiro de Acompanhamento da Obra</span>
            {isCollapsed && (
              <span className="font-mono text-[11px] bg-stone-100 text-stone-800 px-2 py-0.5 font-bold border border-stone-200 uppercase tracking-wider">
                Total Pago: {formatCurrency(totalSpent)}
              </span>
            )}
          </h3>
          <p className="text-xs text-stone-500 mt-0.5">
            Lançamento e controle de despesas executadas (materiais, mão de obra e serviços gerais).
          </p>
        </div>
        <div className="flex items-center gap-2">
          {!isCollapsed && (
            <button
              type="button"
              onClick={() => setIsManualFormOpen(!isManualFormOpen)}
              className="bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-mono uppercase tracking-wider px-3 py-1.5 border border-stone-300 font-bold flex items-center gap-1 cursor-pointer transition-all"
            >
              <Plus size={13} />
              Lançar Manual
            </button>
          )}
          <button
            type="button"
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="bg-white hover:bg-stone-50 border border-stone-300 text-stone-800 text-xs font-mono uppercase tracking-wider px-3 py-1.5 font-bold flex items-center gap-1.5 cursor-pointer transition-all"
            title={isCollapsed ? "Expandir Painel" : "Recolher Painel"}
          >
            {isCollapsed ? (
              <>
                <ChevronDown size={14} className="text-stone-600" />
                <span>Expandir</span>
              </>
            ) : (
              <>
                <ChevronUp size={14} className="text-stone-600" />
                <span>Minimizar</span>
              </>
            )}
          </button>
        </div>
      </div>

      {!isCollapsed && (
        <>
          {/* Google Workspace Connection status banner */}
          <div className="bg-[#FAF9F6] border border-stone-200 p-5 space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-stone-150 pb-3">
              <div className="space-y-1">
                <span className="text-[9px] font-mono uppercase tracking-widest text-stone-400 block font-bold">
                  Integração Google Workspace / Google Drive
                </span>
                {user ? (
                  <div className="flex flex-col gap-0.5">
                    <div className="flex items-center gap-1.5">
                      <CheckCircle2 size={13} className="text-emerald-600" />
                      <span className="text-xs font-medium text-stone-800">
                        Google Drive conectado como <strong className="font-semibold">{user.email}</strong>
                      </span>
                    </div>
                    {folderId && (
                      <a
                        href={`https://drive.google.com/drive/folders/${folderId}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[10px] text-stone-500 hover:text-stone-900 font-mono underline inline-flex items-center gap-1 mt-1"
                      >
                        <Folder size={11} className="text-stone-400" />
                        Abrir Pasta desta Obra no Drive ↗
                      </a>
                    )}
                  </div>
                ) : (
                  <p className="text-[11px] text-stone-600">
                    Conecte sua conta do Google Drive para armazenamento automático em nuvem de Notas Fiscais e comprovantes.
                  </p>
                )}
              </div>
              <div>
                {user ? (
                  <button
                    type="button"
                    onClick={handleDisconnectDrive}
                    className="bg-red-50 hover:bg-red-100 text-red-700 text-[10px] font-mono uppercase tracking-wider px-3 py-1.5 border border-red-200 font-bold transition-all cursor-pointer"
                  >
                    Desconectar Conta
                  </button>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={isLoggingIn}
                      onClick={handleConnectDrive}
                      className="bg-white border border-stone-300 hover:bg-stone-50 text-stone-700 text-[11px] font-sans font-medium py-1.5 px-3 flex items-center gap-2 transition-all cursor-pointer"
                    >
                      {isLoggingIn ? (
                        <>
                          <Loader2 size={13} className="animate-spin text-stone-500" />
                          <span>Conectando...</span>
                        </>
                      ) : (
                        <>
                          <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="h-3.5 w-3.5">
                            <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                            <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                            <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                            <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                          </svg>
                          <span>Ativar Google Drive (OAuth)</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowManualLogin(!showManualLogin)}
                      className="bg-stone-900 hover:bg-stone-800 text-white text-[10px] font-mono uppercase tracking-wider px-3 py-1.5 border border-transparent font-bold transition-all cursor-pointer"
                    >
                      {showManualLogin ? 'Fechar Login Manual' : 'Conectar Manualmente'}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Manual Credential Login Form */}
            {showManualLogin && !user && (
              <form onSubmit={handleManualLogin} className="bg-white border border-stone-200 p-4 space-y-3.5 max-w-xl">
                <div className="border-b border-stone-150 pb-1.5">
                  <h4 className="font-mono text-[10px] uppercase tracking-wider text-stone-800 font-bold flex items-center gap-1.5">
                    <Folder size={12} className="text-stone-600" />
                    Preencher Dados da Conta Google Drive
                  </h4>
                  <p className="text-[10px] text-stone-500 font-sans mt-0.5">
                    Insira as credenciais e as configurações do diretório onde deseja armazenar os documentos da obra.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[8px] font-mono uppercase text-stone-500 font-bold mb-1">E-mail do Google Drive</label>
                    <input
                      type="email"
                      required
                      placeholder="exemplo@gmail.com"
                      value={manualEmail}
                      onChange={(e) => setManualEmail(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 py-1.5 px-2.5 text-xs font-sans focus:outline-none focus:bg-white focus:border-stone-400 transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] font-mono uppercase text-stone-500 font-bold mb-1">Senha de Aplicativo / PIN</label>
                    <input
                      type="password"
                      required
                      placeholder="••••••••••••"
                      value={manualPassword}
                      onChange={(e) => setManualPassword(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-200 py-1.5 px-2.5 text-xs font-sans focus:outline-none focus:bg-white focus:border-stone-400 transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-500 font-bold mb-1">Nome da Pasta de Destino no Google Drive</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Chaves Brites - Notas Fiscais - Obra..."
                    value={manualFolder}
                    onChange={(e) => setManualFolder(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-200 py-1.5 px-2.5 text-xs font-sans focus:outline-none focus:bg-white focus:border-stone-400 transition-all"
                  />
                  <p className="text-[9px] text-stone-400 mt-1">
                    Esta pasta será localizada ou criada automaticamente na conta indicada para salvar as notas fiscais enviadas.
                  </p>
                </div>

                <div className="flex justify-end gap-2 pt-1.5">
                  <button
                    type="button"
                    onClick={() => setShowManualLogin(false)}
                    className="px-3 py-1 text-xs font-mono uppercase text-stone-500 hover:text-stone-800 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="bg-stone-900 hover:bg-stone-800 text-white text-xs font-mono uppercase tracking-wider font-bold py-1.5 px-4 border border-transparent transition-all cursor-pointer"
                  >
                    Confirmar e Conectar Conta
                  </button>
                </div>
              </form>
            )}
          </div>

      {/* Manual Lançamento Form */}
      {isManualFormOpen && (
        <form onSubmit={handleManualSubmit} className="bg-stone-50 border border-stone-200 p-4 space-y-4">
          <div className="border-b border-stone-200 pb-2">
            <h4 className="font-mono text-xs uppercase tracking-wider text-stone-800 font-bold">Novo Lançamento Financeiro</h4>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Fornecedor / Prestador</label>
              <input
                type="text"
                required
                className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                placeholder="Ex: Madeireira CBC, João Pedreiro"
                value={manualForm.supplier}
                onChange={e => setManualForm({ ...manualForm, supplier: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Nº de NF / Comprovante</label>
              <input
                type="text"
                className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                placeholder="Ex: 12456, s/n"
                value={manualForm.invoiceNumber}
                onChange={e => setManualForm({ ...manualForm, invoiceNumber: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Valor (R$)</label>
              <input
                type="number"
                step="0.01"
                required
                className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none font-mono"
                placeholder="0.00"
                value={manualForm.value}
                onChange={e => setManualForm({ ...manualForm, value: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Data do Pagamento</label>
              <input
                type="date"
                required
                className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                value={manualForm.date}
                onChange={e => setManualForm({ ...manualForm, date: e.target.value })}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Categoria</label>
              <select
                className="w-full bg-white border border-stone-200 py-1.5 px-2 text-xs focus:outline-none"
                value={manualForm.category}
                onChange={e => setManualForm({ ...manualForm, category: e.target.value as TransactionCategory })}
              >
                <option value="materiais">🧱 Materiais de Construção</option>
                <option value="mao_de_obra">👷 Mão de Obra / Serviços</option>
                <option value="projetos_complementares">📐 Projetos Complementares</option>
                <option value="taxas">📄 Taxas / Impostos / Aluguel</option>
                <option value="decoracao">🛋️ Decoração / Interiores</option>
                <option value="outros">📦 Outros Gastos</option>
              </select>
            </div>
            <div>
              <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Descrição Curta</label>
              <input
                type="text"
                className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                placeholder="Ex: Compra de blocos cerâmicos, pagamento da 2ª medição"
                value={manualForm.description}
                onChange={e => setManualForm({ ...manualForm, description: e.target.value })}
              />
            </div>
          </div>

          <div>
            <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Observações / Chave / Informações Bancárias</label>
            <textarea
              className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none h-12 resize-none"
              placeholder="Número de nota fiscal, dados do Pix, etc."
              value={manualForm.notes}
              onChange={e => setManualForm({ ...manualForm, notes: e.target.value })}
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-stone-250">
            <button
              type="button"
              onClick={() => setIsManualFormOpen(false)}
              className="px-3 py-1.5 text-xs font-mono uppercase text-stone-500 hover:text-stone-800 cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="bg-stone-900 text-white hover:bg-stone-800 py-1.5 px-4 text-xs font-mono uppercase tracking-wider font-bold cursor-pointer"
            >
              Gravar Gasto
            </button>
          </div>
        </form>
      )}

      {/* AI INVOICE SCANNING AREA */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left column: Drag and Drop Area */}
        <div className="lg:col-span-1 space-y-4">
          <div className="border border-stone-200 p-4 space-y-3">
            <div className="flex border-b border-stone-100 pb-1 mb-2">
              <button
                type="button"
                onClick={() => setActiveTab('single')}
                className={`flex-1 pb-1.5 text-center font-mono text-[9px] uppercase font-bold tracking-wider cursor-pointer border-b-2 transition-all ${activeTab === 'single' ? 'border-stone-900 text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-600'}`}
              >
                NF Única
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('bulk')}
                className={`flex-1 pb-1.5 text-center font-mono text-[9px] uppercase font-bold tracking-wider cursor-pointer border-b-2 transition-all ${activeTab === 'bulk' ? 'border-stone-900 text-stone-900' : 'border-transparent text-stone-400 hover:text-stone-600'}`}
              >
                Lote (Excel/PDF)
              </button>
            </div>

            {activeTab === 'single' ? (
              <div className="space-y-3">
                <h4 className="font-serif text-xs text-stone-950 font-bold flex items-center gap-1.5">
                  <Sparkles size={14} className="text-stone-700 animate-pulse" />
                  Leitura de NF Única (IA)
                </h4>
                <p className="text-[11px] text-stone-500">
                  Anexe uma Nota Fiscal, fatura ou cupom (PDF ou imagem) e nossa IA fará a leitura integral, preenchendo os dados financeiros automaticamente.
                </p>

                {/* Dual Upload Buttons */}
                <div className="grid grid-cols-1 gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 border-2 border-dashed border-stone-300 hover:border-stone-500 bg-white hover:bg-[#FAF9F6] py-4 px-3 text-xs font-mono uppercase font-bold tracking-wider text-stone-800 transition-all cursor-pointer group"
                  >
                    <Upload size={16} className="text-stone-500 group-hover:text-stone-800" />
                    <span>Adicionar Arquivo Local</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                        startCamera();
                      } else {
                        cameraFileInputRef.current?.click();
                      }
                    }}
                    className="flex items-center justify-center gap-2 border-2 border-dashed border-stone-300 hover:border-stone-500 bg-white hover:bg-[#FAF9F6] py-4 px-3 text-xs font-mono uppercase font-bold tracking-wider text-stone-800 transition-all cursor-pointer group"
                  >
                    <Camera size={16} className="text-stone-500 group-hover:text-stone-800" />
                    <span>Tirar Foto</span>
                  </button>
                </div>

                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  accept="application/pdf,image/*,.xlsx,.xls,.doc,.docx" 
                />

                <input
                  type="file"
                  ref={cameraFileInputRef}
                  onChange={handleCameraFileChange}
                  className="hidden"
                  accept="image/*"
                  capture="environment"
                />

                {selectedFile && (
                  <div className="bg-stone-50 border border-stone-200 p-2.5 flex items-center justify-between text-xs rounded-none">
                    <div className="flex items-center gap-1.5 truncate">
                      <Paperclip size={12} className="text-stone-500 flex-shrink-0" />
                      <span className="truncate font-mono text-[10.5px]" title={selectedFile.name}>
                        {selectedFile.name}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCancelScanned}
                      className="text-red-500 hover:text-red-700 font-mono text-[10px] uppercase ml-1"
                    >
                      Excluir
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                <h4 className="font-serif text-xs text-stone-950 font-bold flex items-center gap-1.5">
                  <Sparkles size={14} className="text-stone-700 animate-pulse" />
                  Importar em Lote (IA)
                </h4>
                <p className="text-[11px] text-stone-500">
                  Importe uma planilha do Excel (.xlsx, .xls), extrato bancário em PDF ou lista de despesas em formato CSV. A IA irá extrair e listar todos os lançamentos simultaneamente.
                </p>

                {/* Drag & Drop Stage */}
                <div 
                  onClick={() => bulkFileInputRef.current?.click()}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const file = e.dataTransfer.files?.[0];
                    if (file) processBulkFile(file);
                  }}
                  className="border-2 border-dashed border-stone-300 hover:border-stone-500 py-8 px-4 text-center cursor-pointer transition-all bg-[#FAF9F6] group"
                >
                  <input 
                    type="file" 
                    ref={bulkFileInputRef} 
                    onChange={handleBulkFileChange} 
                    className="hidden" 
                    accept=".xlsx,.xls,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,text/csv,application/pdf" 
                  />
                  <Upload size={24} className="mx-auto text-stone-400 group-hover:text-stone-600 mb-2 transition-all" />
                  <span className="text-xs font-mono uppercase tracking-wide font-bold text-stone-700 block mb-0.5">
                    Selecionar Planilha / PDF
                  </span>
                  <span className="text-[9px] text-stone-400 block font-sans">
                    Arraste o arquivo Excel, CSV ou PDF ou clique para abrir.
                  </span>
                </div>

                {bulkFile && (
                  <div className="bg-stone-50 border border-stone-200 p-2.5 flex items-center justify-between text-xs rounded-none">
                    <div className="flex items-center gap-1.5 truncate">
                      <Paperclip size={12} className="text-stone-500 flex-shrink-0" />
                      <span className="truncate font-mono text-[10.5px]" title={bulkFile.name}>
                        {bulkFile.name}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleCancelBulk}
                      className="text-red-500 hover:text-red-700 font-mono text-[10px] uppercase ml-1"
                    >
                      Excluir
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Right column: AI Parsing result / validation */}
        <div className="lg:col-span-2">
          {isBulkParsing ? (
            <div className="border border-stone-200 h-full min-h-[180px] p-8 flex flex-col items-center justify-center text-center bg-[#FCFBF9] space-y-3">
              <Loader2 size={28} className="text-stone-700 animate-spin" />
              <div className="space-y-1">
                <h5 className="font-serif text-sm font-bold text-stone-900">Processamento de Lote por IA</h5>
                <p className="text-xs text-stone-500 max-w-sm leading-relaxed">
                  Lendo planilha ou extrato com o Gemini 3.5... Identificando fornecedores, descrições, valores, categorias e datas de despesas da obra para importação simultânea. Por favor, aguarde alguns instantes.
                </p>
              </div>
            </div>
          ) : bulkTransactions ? (
            // Bulk transactions review table
            <div className="border border-stone-200 p-5 space-y-4 bg-[#FCFBF9]">
              <div className="border-b border-stone-200 pb-2.5 flex items-center justify-between">
                <h4 className="font-serif text-xs text-stone-950 font-bold flex items-center gap-1.5">
                  <Sparkles size={15} className="text-stone-700" />
                  Revisar Lançamentos Extraídos ({bulkTransactions.length})
                </h4>
                <span className="text-[8px] font-mono uppercase bg-stone-100 text-stone-800 px-1.5 py-0.5 font-bold">
                  Importação em Lote por IA
                </span>
              </div>

              <div className="overflow-x-auto border border-stone-150 max-h-[300px] bg-white">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-stone-50 font-mono text-[9px] uppercase text-stone-500 border-b border-stone-200">
                      <th className="p-2 w-8 text-center">
                        <input
                          type="checkbox"
                          checked={bulkTransactions.every(t => t.selected)}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setBulkTransactions(bulkTransactions.map(t => ({ ...t, selected: checked })));
                          }}
                          className="h-3 w-3 accent-stone-900 cursor-pointer"
                        />
                      </th>
                      <th className="p-2 w-24">Data</th>
                      <th className="p-2">Fornecedor</th>
                      <th className="p-2">Descrição</th>
                      <th className="p-2 w-28">Categoria</th>
                      <th className="p-2 text-right w-24">Valor</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-150 font-sans">
                    {bulkTransactions.map((t, idx) => (
                      <tr key={idx} className={`hover:bg-stone-50/50 align-middle ${!t.selected ? 'opacity-50' : ''}`}>
                        <td className="p-2 text-center">
                          <input
                            type="checkbox"
                            checked={!!t.selected}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].selected = e.target.checked;
                              setBulkTransactions(updated);
                            }}
                            className="h-3 w-3 accent-stone-900 cursor-pointer"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="date"
                            value={t.date}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].date = e.target.value;
                              setBulkTransactions(updated);
                            }}
                            className="bg-transparent border-0 focus:bg-white focus:ring-1 focus:ring-stone-400 p-1 w-full text-[11px] font-mono"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={t.supplier}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].supplier = e.target.value;
                              setBulkTransactions(updated);
                            }}
                            className="bg-transparent border-0 focus:bg-white focus:ring-1 focus:ring-stone-400 p-1 w-full font-bold text-stone-900 text-[11px]"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={t.description}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].description = e.target.value;
                              setBulkTransactions(updated);
                            }}
                            className="bg-transparent border-0 focus:bg-white focus:ring-1 focus:ring-stone-400 p-1 w-full text-stone-600 text-[11px]"
                          />
                        </td>
                        <td className="p-2">
                          <select
                            value={t.category}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].category = e.target.value as TransactionCategory;
                              setBulkTransactions(updated);
                            }}
                            className="bg-transparent border-0 focus:bg-white focus:ring-1 focus:ring-stone-400 p-1 w-full text-[10px] font-mono"
                          >
                            <option value="materiais">🧱 Materiais</option>
                            <option value="mao_de_obra">👷 Mão de Obra</option>
                            <option value="projetos_complementares">📐 Proj. Compl.</option>
                            <option value="taxas">🏛️ Taxas</option>
                            <option value="decoracao">🛋️ Decoração</option>
                            <option value="outros">📦 Outros</option>
                          </select>
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            step="0.01"
                            value={t.value}
                            onChange={(e) => {
                              const updated = [...bulkTransactions];
                              updated[idx].value = parseFloat(e.target.value) || 0;
                              setBulkTransactions(updated);
                            }}
                            className="bg-transparent border-0 focus:bg-white focus:ring-1 focus:ring-stone-400 p-1 w-full font-mono text-right font-bold text-stone-950 text-[11px]"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2">
                <span className="text-[10px] text-stone-500 font-mono">
                  Selecionados: <strong>{bulkTransactions.filter(t => t.selected).length} de {bulkTransactions.length}</strong> | Total: <strong>{formatCurrency(bulkTransactions.filter(t => t.selected).reduce((acc, t) => acc + t.value, 0))}</strong>
                </span>
                <div className="flex gap-2 self-end">
                  <button
                    type="button"
                    onClick={handleCancelBulk}
                    className="px-3 py-1.5 text-xs font-mono uppercase text-stone-500 hover:text-stone-800 cursor-pointer"
                  >
                    Descartar
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveBulkTransactions}
                    className="bg-stone-900 text-white hover:bg-stone-800 py-1.5 px-4 text-xs font-mono uppercase tracking-wider font-bold cursor-pointer"
                  >
                    Importar Selecionados
                  </button>
                </div>
              </div>
            </div>
          ) : bulkError ? (
            <div className="border border-red-200 bg-red-50/5 p-5 space-y-4 h-full min-h-[180px] flex flex-col justify-center">
              <div className="bg-red-50 border border-red-200 p-3 text-xs text-red-800 flex items-start gap-2.5">
                <AlertTriangle size={16} className="text-red-600 mt-0.5 flex-shrink-0" />
                <div>
                  <strong className="block font-bold text-red-900">Erro na Importação Inteligente</strong>
                  <span className="text-[11px] text-red-700 leading-normal">
                    {bulkError}
                  </span>
                </div>
              </div>
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={handleCancelBulk}
                  className="bg-stone-900 text-white hover:bg-stone-800 py-1.5 px-4 text-xs font-mono uppercase tracking-wider font-bold cursor-pointer"
                >
                  Tentar Novamente
                </button>
              </div>
            </div>
          ) : isParsing ? (
            <div className="border border-stone-200 h-full min-h-[180px] p-8 flex flex-col items-center justify-center text-center bg-[#FCFBF9] space-y-3">
              <Loader2 size={28} className="text-stone-700 animate-spin" />
              <div className="space-y-1">
                <h5 className="font-serif text-sm font-bold text-stone-900">Análise de Documento com IA</h5>
                <p className="text-xs text-stone-500 max-w-sm leading-relaxed">
                  Lendo Nota Fiscal com o Gemini 3.5... extraindo fornecedor, datas de faturamento, valores totais e itens do cupom. Por favor, aguarde alguns instantes.
                </p>
              </div>
            </div>
          ) : scannedData ? (
            // Validation screen
            <div className={`border p-5 space-y-4 ${aiError ? 'border-amber-200 bg-amber-50/5' : 'border-emerald-200 bg-emerald-50/10'}`}>
              {aiError ? (
                <div className="bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800 flex items-start gap-2.5">
                  <AlertTriangle size={16} className="text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <strong className="block font-bold text-amber-900">Aviso da IA: Leitura automática indisponível</strong>
                    <span className="text-[11px] text-amber-700 leading-normal">
                      Não conseguimos extrair as informações automaticamente do arquivo ({aiError}).
                      Contudo, <strong>o seu arquivo permanece anexado</strong>. Por favor, preencha os campos abaixo manualmente para que ele seja salvo corretamente e enviado ao Google Drive com a nomenclatura formatada.
                    </span>
                  </div>
                </div>
              ) : (
                <div className="border-b border-emerald-150 pb-2.5 flex items-center justify-between">
                  <h4 className="font-serif text-xs text-emerald-950 font-bold flex items-center gap-1.5">
                    <CheckCircle2 size={15} className="text-emerald-700" />
                    Dados Extraídos com Sucesso! Verifique abaixo:
                  </h4>
                  <span className="text-[8px] font-mono uppercase bg-emerald-100 text-emerald-800 px-1.5 py-0.5 font-bold">
                    Extração Inteligente
                  </span>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Fornecedor / Prestador</label>
                  <input
                    type="text"
                    className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                    value={scannedData.supplier}
                    onChange={e => setScannedData({ ...scannedData, supplier: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Nº de NF / Comprovante</label>
                  <input
                    type="text"
                    className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                    value={scannedData.invoiceNumber}
                    onChange={e => setScannedData({ ...scannedData, invoiceNumber: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Valor Calculado (R$)</label>
                  <input
                    type="number"
                    step="0.01"
                    className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none font-mono font-bold"
                    value={scannedData.value}
                    onChange={e => setScannedData({ ...scannedData, value: parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Data Identificada</label>
                  <input
                    type="date"
                    className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                    value={scannedData.date}
                    onChange={e => setScannedData({ ...scannedData, date: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Categoria Definida</label>
                  <select
                    className="w-full bg-white border border-stone-200 py-1.5 px-2 text-xs focus:outline-none"
                    value={scannedData.category}
                    onChange={e => setScannedData({ ...scannedData, category: e.target.value as TransactionCategory })}
                  >
                    <option value="materiais">🧱 Materiais de Construção</option>
                    <option value="mao_de_obra">👷 Mão de Obra / Serviços</option>
                    <option value="outros">📦 Outros Gastos</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Descrição Proposta</label>
                  <input
                    type="text"
                    className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none"
                    value={scannedData.description}
                    onChange={e => setScannedData({ ...scannedData, description: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Observações Adicionais Extraídas</label>
                <textarea
                  className="w-full bg-white border border-stone-200 py-1.5 px-2.5 text-xs focus:outline-none h-12 resize-none text-stone-600"
                  value={scannedData.notes}
                  onChange={e => setScannedData({ ...scannedData, notes: e.target.value })}
                />
              </div>

              {/* Drive upload toggling */}
              {user && folderId && (
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="save_to_drive_check"
                    checked={saveToDriveChecked}
                    onChange={(e) => setSaveToDriveChecked(e.target.checked)}
                    className="h-3.5 w-3.5 border-stone-300 accent-stone-900 cursor-pointer"
                  />
                  <label htmlFor="save_to_drive_check" className="text-xs text-stone-600 cursor-pointer flex items-center gap-1">
                    Salvar nota original na pasta organizada da obra no Google Drive
                  </label>
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2 border-t border-emerald-150">
                <button
                  type="button"
                  onClick={handleCancelScanned}
                  className="px-3 py-1.5 text-xs font-mono uppercase text-stone-500 hover:text-stone-800 cursor-pointer"
                >
                  Descartar
                </button>
                <button
                  type="button"
                  disabled={isUploadingToDrive}
                  onClick={handleSaveScannedInvoice}
                  className="bg-emerald-800 text-white hover:bg-emerald-900 py-1.5 px-4 text-xs font-mono uppercase tracking-wider font-bold cursor-pointer flex items-center gap-1.5"
                >
                  {isUploadingToDrive ? (
                    <>
                      <Loader2 size={12} className="animate-spin" />
                      Enviando para o Drive...
                    </>
                  ) : (
                    <>
                      Confirmar e Salvar Lançamento
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            // Default placeholder waiting
            <div className="border border-stone-200 h-full min-h-[180px] p-8 flex flex-col items-center justify-center text-center bg-stone-50/10 text-stone-400">
              <FileText size={28} className="text-stone-300 mb-2" />
              <span className="text-xs font-mono uppercase font-bold tracking-wide text-stone-500 mb-1">
                Visualização do Lançamento por IA
              </span>
              <p className="text-[11px] max-w-xs leading-normal">
                Faça o upload ou arraste um documento ao lado. A extração dos valores será demonstrada aqui de forma interativa para sua confirmação antes do salvamento.
              </p>
            </div>
          )}
        </div>

      </div>

      {/* Financial statement summary */}
      <div className="bg-stone-50 border border-stone-200 p-4 grid grid-cols-2 md:grid-cols-3 gap-4">
        <div>
          <span className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Gasto Total Acumulado</span>
          <span className="font-mono font-bold text-stone-950 text-[15px]">{formatCurrency(totalSpent)}</span>
        </div>
        <div>
          <span className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Gasto com Materiais</span>
          <span className="font-mono font-bold text-amber-800 text-[14px]">
            {formatCurrency(projectTransactions.filter(t => t.category === 'materiais').reduce((acc, t) => acc + t.value, 0))}
          </span>
        </div>
        <div>
          <span className="block text-[8px] font-mono uppercase text-stone-400 font-bold">Gasto com Mão de Obra</span>
          <span className="font-mono font-bold text-emerald-800 text-[14px]">
            {formatCurrency(projectTransactions.filter(t => t.category === 'mao_de_obra').reduce((acc, t) => acc + t.value, 0))}
          </span>
        </div>
      </div>

      {/* Transactions List */}
      <div className="space-y-3">
        <div className="flex justify-between items-center border-b border-stone-100 pb-2">
          <h4 className="font-mono text-xs uppercase tracking-wider text-stone-800 font-bold">
            Extrato de Gastos Lançados ({projectTransactions.length})
          </h4>
        </div>

        <div className="overflow-x-auto border border-stone-200">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-stone-50 font-mono text-[9px] uppercase tracking-wider text-stone-500 border-b border-stone-200">
                <th className="p-3 w-28">Data</th>
                <th className="p-3">Fornecedor / Prestador</th>
                <th className="p-3">Descrição</th>
                <th className="p-3 w-32">Categoria</th>
                <th className="p-3 text-right w-32">Valor</th>
                <th className="p-3 text-center w-24">Comprovante</th>
                <th className="p-3 text-center w-12">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-150 font-sans">
              {projectTransactions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-6 text-center text-stone-400 text-xs">
                    Nenhum pagamento ou gasto registrado para esta obra.
                  </td>
                </tr>
              ) : (
                projectTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-stone-50/50 align-middle">
                    <td className="p-3 font-mono text-[11px] text-stone-500">
                      {tx.date}
                    </td>
                    <td className="p-3">
                      <div className="font-bold text-stone-900">{tx.supplier}</div>
                      {tx.invoiceNumber && (
                        <div className="text-[10px] text-stone-500 font-mono mt-0.5" title="Número da Nota Fiscal / Comprovante">
                          NF: {tx.invoiceNumber}
                        </div>
                      )}
                    </td>
                    <td className="p-3 text-stone-600">
                      {tx.description}
                    </td>
                    <td className="p-3">
                      <span className={`inline-block px-2 py-0.5 text-[9px] font-mono border rounded-none ${getCategoryBadgeColor(tx.category)}`}>
                        {getCategoryLabel(tx.category)}
                      </span>
                    </td>
                    <td className="p-3 text-right font-mono font-bold text-stone-950">
                      {formatCurrency(tx.value)}
                    </td>
                    <td className="p-3 text-center">
                      {tx.receiptName ? (
                        tx.receiptName.startsWith('http') ? (
                          <a
                            href={tx.receiptName}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-stone-100 hover:bg-stone-200 border border-stone-300 text-stone-700 py-1 px-2 text-[9px] font-mono uppercase font-bold inline-flex items-center gap-1 cursor-pointer transition-all rounded-none"
                            title="Ver Nota Fiscal no Google Drive"
                          >
                            <Folder size={10} className="text-stone-500" />
                            Drive ↗
                          </a>
                        ) : tx.receiptBase64 ? (
                          <a
                            href={tx.receiptBase64}
                            download={tx.receiptName.replace('Local: ', '')}
                            className="bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-800 py-1 px-2 text-[9px] font-mono uppercase font-bold inline-flex items-center gap-1 cursor-pointer transition-all rounded-none"
                            title="Baixar ou Visualizar Arquivo Anexado"
                          >
                            <Paperclip size={10} className="text-amber-600" />
                            Anexo ↗
                          </a>
                        ) : (
                          <span className="text-[10px] text-stone-400 font-mono italic" title={tx.receiptName}>
                            Simulado
                          </span>
                        )
                      ) : (
                        <span className="text-[10px] text-stone-400 font-mono">
                          —
                        </span>
                      )}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        type="button"
                        onClick={() => {
                          if (window.confirm('Tem certeza que deseja excluir este lançamento financeiro permanentemente?')) {
                            deleteTransaction(tx.id);
                          }
                        }}
                        className="text-stone-400 hover:text-red-700 transition-all cursor-pointer p-1"
                        title="Excluir Gasto"
                      >
                        <Trash2 size={13} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

        </>
      )}

      {/* Interactive Camera Modal Overlay */}
      {isCameraActive && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex flex-col items-center justify-center p-4">
          <div className="relative w-full max-w-md bg-stone-900 border border-stone-800 p-6 space-y-4 flex flex-col items-center">
            {/* Header */}
            <div className="w-full flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <Camera className="text-stone-400 animate-pulse" size={16} />
                <span className="font-mono text-xs text-stone-300 uppercase tracking-wider font-bold text-left">Captura de Documento</span>
              </div>
              <button
                type="button"
                onClick={stopCamera}
                className="text-stone-400 hover:text-white transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Video Stream / Error Container */}
            <div className="relative w-full aspect-[3/4] bg-stone-950 border border-stone-800 flex items-center justify-center overflow-hidden">
              {cameraError ? (
                <div className="p-4 text-center space-y-3">
                  <AlertCircle size={32} className="text-red-500 mx-auto" />
                  <p className="text-xs text-stone-300 leading-relaxed font-sans">{cameraError}</p>
                  <button
                    type="button"
                    onClick={() => {
                      stopCamera();
                      cameraFileInputRef.current?.click();
                    }}
                    className="bg-stone-800 text-white hover:bg-stone-700 py-1.5 px-4 text-[10px] font-mono uppercase tracking-wider font-bold cursor-pointer transition-colors"
                  >
                    Usar Câmera Nativa do Celular
                  </button>
                </div>
              ) : (
                <>
                  {/* Guide rectangle overlay */}
                  <div className="absolute inset-4 border-2 border-dashed border-white/20 pointer-events-none flex items-center justify-center z-10">
                    <span className="text-[9px] font-mono uppercase text-white/40 tracking-widest text-center max-w-[180px]">
                      Alinhe o Comprovante ou Nota Fiscal aqui
                    </span>
                  </div>
                  
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover"
                  />
                </>
              )}
            </div>

            {/* Actions */}
            {!cameraError && (
              <div className="w-full flex justify-between items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={stopCamera}
                  className="text-xs font-mono uppercase text-stone-400 hover:text-stone-200 py-2 cursor-pointer"
                >
                  Cancelar
                </button>
                
                <button
                  type="button"
                  onClick={capturePhoto}
                  className="flex-1 bg-stone-100 hover:bg-white text-stone-900 py-2.5 px-4 text-xs font-mono uppercase tracking-widest font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
                >
                  <Camera size={14} />
                  <span>Tirar Foto</span>
                </button>
              </div>
            )}

            {/* Hidden Canvas for capture rendering */}
            <canvas ref={canvasRef} className="hidden" />
          </div>
        </div>
      )}

    </div>
  );
}
