import React, { useState, useEffect, useMemo } from 'react';
import { 
  Megaphone, 
  Calendar, 
  FileText, 
  Plus, 
  Trash2, 
  Edit, 
  Search, 
  DollarSign, 
  Percent, 
  Sparkles, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  TrendingUp, 
  Share2, 
  Copy, 
  Check, 
  Filter,
  ArrowUpRight,
  ExternalLink,
  ChevronRight,
  Instagram,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { subscribeCollection, saveDoc, removeDoc } from '../lib/firebaseDb';
import { MarketingCampaign, MarketingPost } from '../types';

interface BrandAsset {
  id: string;
  name: string;
  type: string;
  size: string;
  description: string;
  link: string;
}

const DEFAULT_CAMPAIGNS: MarketingCampaign[] = [
  {
    id: 'camp_1',
    name: 'Instagram Alto Padrão - Verão 2026',
    platform: 'Instagram',
    budget: 3500,
    spent: 2800,
    leadsCount: 42,
    status: 'ativo',
    startDate: '2026-06-15',
    notes: 'Foco em carrosséis de fotos reais de obras concluídas e reels de design de interiores sofisticado.'
  },
  {
    id: 'camp_2',
    name: 'Google Ads - Reformas de Luxo',
    platform: 'Google Ads',
    budget: 5000,
    spent: 1500,
    leadsCount: 28,
    status: 'ativo',
    startDate: '2026-07-01',
    notes: 'Segmentação por palavras-chave de intenção de compra: "projeto de casa de alto padrão", "reforma residencial luxo".'
  },
  {
    id: 'camp_3',
    name: 'Pinterest Decoração & Conceito',
    platform: 'Pinterest',
    budget: 1500,
    spent: 1500,
    leadsCount: 15,
    status: 'concluido',
    startDate: '2026-05-10',
    notes: 'Imagens inspiradoras de fachadas modernas e cozinhas integradas, redirecionando para o portfólio no site.'
  },
  {
    id: 'camp_4',
    name: 'Vídeos de Portfólio YouTube',
    platform: 'YouTube',
    budget: 2500,
    spent: 400,
    leadsCount: 4,
    status: 'planejado',
    startDate: '2026-08-01',
    notes: 'Produção de mini documentários mostrando o antes e depois de obras icônicas com depoimentos de clientes.'
  }
];

const DEFAULT_POSTS: MarketingPost[] = [
  {
    id: 'post_1',
    title: 'Visita Técnica Obra Barra da Tijuca',
    platform: 'Instagram',
    publishDate: '2026-07-15',
    status: 'agendado',
    caption: 'Acompanhando cada detalhe da concretagem de hoje na Barra. Engenharia de ponta e arquitetura alinhadas! 🏗️📐 #ChavesBrites #Obra #AltoPadrao #Engenharia'
  },
  {
    id: 'post_2',
    title: 'Por que planejar o fluxo de iluminação?',
    platform: 'Pinterest',
    publishDate: '2026-07-18',
    status: 'rascunho',
    caption: 'Mais do que clarear o ambiente, a iluminação define o aconchego e a imponência de um espaço de alto padrão. Salve essa referência de sala de estar integrada! 💡🏠'
  },
  {
    id: 'post_3',
    title: 'Tour Virtual Completo - Casa Joá',
    platform: 'YouTube',
    publishDate: '2026-07-10',
    status: 'publicado',
    caption: 'Assista ao tour detalhado por este projeto de encostas que une a vista infinita do oceano com o minimalismo em concreto aparente. Link na bio! 🌊💎'
  },
  {
    id: 'post_4',
    title: 'Tendências de Arquitetura Biofílica',
    platform: 'Instagram',
    publishDate: '2026-07-22',
    status: 'agendado',
    caption: 'Como a natureza integrada ao concreto melhora o bem-estar diário. No nosso novo projeto, cada janela emoldura uma árvore viva. Qual a sua opinião sobre essa integração? 🌱🏢 #Biofilia #DesignGreen'
  }
];

const DEFAULT_ASSETS: BrandAsset[] = [
  {
    id: 'asset_1',
    name: 'Logotipo Oficial Chaves Brites - Vetorizado',
    type: 'Vetor / Imagem (SVG, PNG)',
    size: '1.2 MB',
    description: 'Versões primária (escura), secundária (clara) e ícone isolado para aplicações digitais e impressas.',
    link: 'https://ais-dev-wu46blmpk55wfohzwqpn4y-377629816056.us-west2.run.app/assets/logo_vector.zip'
  },
  {
    id: 'asset_2',
    name: 'Apresentação Institucional Corporativa 2026',
    type: 'Documento (PDF)',
    size: '8.4 MB',
    description: 'Apresentação contendo história da construtora, equipe diretiva, principais prêmios e portfólio reduzido.',
    link: 'https://ais-dev-wu46blmpk55wfohzwqpn4y-377629816056.us-west2.run.app/assets/apresentacao_institucional.pdf'
  },
  {
    id: 'asset_3',
    name: 'Template de Proposta Comercial - Arquitetura',
    type: 'Modelo (Canva / PDF)',
    size: '4.5 MB',
    description: 'Layout para propostas de anteprojeto e projeto executivo, contendo escopo, cronograma e formas de pagamento.',
    link: 'https://canva.com/brand/templates/chaves_brites_proposal'
  },
  {
    id: 'asset_4',
    name: 'Manual de Identidade Visual CBC v2.1',
    type: 'Guia Técnico (PDF)',
    size: '12.0 MB',
    description: 'Manual de uso da marca contendo paleta de cores institucional, famílias tipográficas (Inter e Oswald) e grids de alinhamento.',
    link: 'https://ais-dev-wu46blmpk55wfohzwqpn4y-377629816056.us-west2.run.app/assets/brand_manual.pdf'
  }
];

export function MarketingManagement() {
  const [activeSubTab, setActiveSubTab] = useState<'campanhas' | 'calendario' | 'ativos'>('campanhas');
  
  // Real-time Firestore state
  const [campaigns, setCampaigns] = useState<MarketingCampaign[]>([]);
  const [posts, setPosts] = useState<MarketingPost[]>([]);
  const [assets, setAssets] = useState<BrandAsset[]>([]);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');

  // Copy success notifications
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Form states
  const [isCampaignModalOpen, setIsCampaignModalOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState<MarketingCampaign | null>(null);
  const [campaignForm, setCampaignForm] = useState<Omit<MarketingCampaign, 'id'>>({
    name: '',
    platform: 'Instagram',
    budget: 0,
    spent: 0,
    leadsCount: 0,
    status: 'planejado',
    startDate: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<MarketingPost | null>(null);
  const [postForm, setPostForm] = useState<Omit<MarketingPost, 'id'>>({
    title: '',
    platform: 'Instagram',
    publishDate: new Date().toISOString().split('T')[0],
    status: 'rascunho',
    caption: ''
  });

  const [isAssetModalOpen, setIsAssetModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<BrandAsset | null>(null);
  const [assetForm, setAssetForm] = useState<Omit<BrandAsset, 'id'>>({
    name: '',
    type: 'Documento (PDF)',
    size: '1.0 MB',
    description: '',
    link: ''
  });

  // Load subscriptions to Firestore collections
  useEffect(() => {
    const unsubscribeCampaigns = subscribeCollection(
      'marketing_campaigns',
      (data) => {
        setCampaigns(data as MarketingCampaign[]);
      },
      DEFAULT_CAMPAIGNS,
      'cbc_marketing_campaigns'
    );

    const unsubscribePosts = subscribeCollection(
      'marketing_posts',
      (data) => {
        setPosts(data as MarketingPost[]);
      },
      DEFAULT_POSTS,
      'cbc_marketing_posts'
    );

    const unsubscribeAssets = subscribeCollection(
      'marketing_assets',
      (data) => {
        setAssets(data as BrandAsset[]);
      },
      DEFAULT_ASSETS,
      'cbc_marketing_assets'
    );

    return () => {
      unsubscribeCampaigns();
      unsubscribePosts();
      unsubscribeAssets();
    };
  }, []);

  // Quick statistics calculation
  const stats = useMemo(() => {
    const totalCampaigns = campaigns.length;
    const activeCampaigns = campaigns.filter(c => c.status === 'ativo').length;
    
    const totalBudget = campaigns.reduce((acc, c) => acc + c.budget, 0);
    const totalSpent = campaigns.reduce((acc, c) => acc + c.spent, 0);
    const totalLeads = campaigns.reduce((acc, c) => acc + c.leadsCount, 0);
    const avgCPL = totalLeads > 0 ? totalSpent / totalLeads : 0;

    const scheduledPosts = posts.filter(p => p.status === 'agendado').length;
    const publishedPosts = posts.filter(p => p.status === 'publicado').length;

    return {
      totalCampaigns,
      activeCampaigns,
      totalBudget,
      totalSpent,
      totalLeads,
      avgCPL,
      scheduledPosts,
      publishedPosts
    };
  }, [campaigns, posts]);

  // Campaign handlers
  const handleOpenCampaignModal = (campaign?: MarketingCampaign) => {
    if (campaign) {
      setEditingCampaign(campaign);
      setCampaignForm({
        name: campaign.name,
        platform: campaign.platform,
        budget: campaign.budget,
        spent: campaign.spent,
        leadsCount: campaign.leadsCount,
        status: campaign.status,
        startDate: campaign.startDate,
        notes: campaign.notes || ''
      });
    } else {
      setEditingCampaign(null);
      setCampaignForm({
        name: '',
        platform: 'Instagram',
        budget: 0,
        spent: 0,
        leadsCount: 0,
        status: 'planejado',
        startDate: new Date().toISOString().split('T')[0],
        notes: ''
      });
    }
    setIsCampaignModalOpen(true);
  };

  const handleSaveCampaign = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingCampaign ? editingCampaign.id : `camp_${Date.now()}`;
    const data: MarketingCampaign = {
      id,
      ...campaignForm
    };
    await saveDoc('marketing_campaigns', id, data);
    setIsCampaignModalOpen(false);
  };

  const handleDeleteCampaign = async (id: string) => {
    if (confirm('Tem certeza de que deseja excluir esta campanha de marketing?')) {
      await removeDoc('marketing_campaigns', id);
    }
  };

  // Post handlers
  const handleOpenPostModal = (post?: MarketingPost) => {
    if (post) {
      setEditingPost(post);
      setPostForm({
        title: post.title,
        platform: post.platform,
        publishDate: post.publishDate,
        status: post.status,
        caption: post.caption || ''
      });
    } else {
      setEditingPost(null);
      setPostForm({
        title: '',
        platform: 'Instagram',
        publishDate: new Date().toISOString().split('T')[0],
        status: 'rascunho',
        caption: ''
      });
    }
    setIsPostModalOpen(true);
  };

  const handleSavePost = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingPost ? editingPost.id : `post_${Date.now()}`;
    const data: MarketingPost = {
      id,
      ...postForm
    };
    await saveDoc('marketing_posts', id, data);
    setIsPostModalOpen(false);
  };

  const handleDeletePost = async (id: string) => {
    if (confirm('Tem certeza de que deseja excluir esta publicação?')) {
      await removeDoc('marketing_posts', id);
    }
  };

  // Asset handlers
  const handleOpenAssetModal = (asset?: BrandAsset) => {
    if (asset) {
      setEditingAsset(asset);
      setAssetForm({
        name: asset.name,
        type: asset.type,
        size: asset.size,
        description: asset.description,
        link: asset.link
      });
    } else {
      setEditingAsset(null);
      setAssetForm({
        name: '',
        type: 'Documento (PDF)',
        size: '1.0 MB',
        description: '',
        link: ''
      });
    }
    setIsAssetModalOpen(true);
  };

  const handleSaveAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    const id = editingAsset ? editingAsset.id : `asset_${Date.now()}`;
    const data: BrandAsset = {
      id,
      ...assetForm
    };
    await saveDoc('marketing_assets', id, data);
    setIsAssetModalOpen(false);
  };

  const handleDeleteAsset = async (id: string) => {
    if (confirm('Tem certeza de que deseja excluir este ativo de marca?')) {
      await removeDoc('marketing_assets', id);
    }
  };

  const handleCopyLink = (id: string, link: string) => {
    navigator.clipboard.writeText(link);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filter lists based on search and filters
  const filteredCampaigns = useMemo(() => {
    return campaigns.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            c.platform.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (c.notes && c.notes.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesStatus = statusFilter === 'todos' || c.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [campaigns, searchQuery, statusFilter]);

  const filteredPosts = useMemo(() => {
    return posts.filter(p => {
      const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.platform.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            (p.caption && p.caption.toLowerCase().includes(searchQuery.toLowerCase()));
      const matchesStatus = statusFilter === 'todos' || p.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [posts, searchQuery, statusFilter]);

  const filteredAssets = useMemo(() => {
    return assets.filter(a => {
      return a.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
             a.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
             a.type.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [assets, searchQuery]);

  return (
    <div className="space-y-8" id="marketing_management_container">
      {/* Title & Actions Row */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-stone-200 pb-5">
        <div>
          <h2 className="font-serif text-xl md:text-2xl text-stone-900 tracking-tight flex items-center gap-2">
            <Megaphone className="text-orange-500" size={24} />
            Área de Marketing Separada
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            Gestão completa de campanhas de tráfego pago, cronograma de publicações digitais e biblioteca de ativos institucionais.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {activeSubTab === 'campanhas' && (
            <button
              onClick={() => handleOpenCampaignModal()}
              className="bg-stone-900 hover:bg-stone-800 text-white font-mono text-[10px] uppercase tracking-wider font-bold py-2.5 px-4 flex items-center gap-2 border border-stone-800 transition-all cursor-pointer"
            >
              <Plus size={14} /> Nova Campanha
            </button>
          )}
          {activeSubTab === 'calendario' && (
            <button
              onClick={() => handleOpenPostModal()}
              className="bg-stone-900 hover:bg-stone-800 text-white font-mono text-[10px] uppercase tracking-wider font-bold py-2.5 px-4 flex items-center gap-2 border border-stone-800 transition-all cursor-pointer"
            >
              <Plus size={14} /> Agendar Publicação
            </button>
          )}
          {activeSubTab === 'ativos' && (
            <button
              onClick={() => handleOpenAssetModal()}
              className="bg-stone-900 hover:bg-stone-800 text-white font-mono text-[10px] uppercase tracking-wider font-bold py-2.5 px-4 flex items-center gap-2 border border-stone-800 transition-all cursor-pointer"
            >
              <Plus size={14} /> Adicionar Ativo
            </button>
          )}
        </div>
      </div>

      {/* METRICS ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        <div className="bg-white border border-stone-200 p-5 space-y-2 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-stone-50 rounded-full translate-x-12 -translate-y-12 -z-0"></div>
          <p className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Investimento Total Previsto</p>
          <div className="flex items-baseline gap-1 relative z-10">
            <span className="text-xl md:text-2xl font-serif font-bold text-stone-900">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.totalBudget)}
            </span>
          </div>
          <div className="text-[10px] text-stone-500 font-mono flex items-center gap-1.5 pt-1">
            <span className="text-stone-400">{stats.totalCampaigns} campanhas cadastradas</span>
          </div>
        </div>

        <div className="bg-white border border-stone-200 p-5 space-y-2 relative overflow-hidden">
          <p className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Total Investido Real</p>
          <div className="flex items-baseline gap-1">
            <span className="text-xl md:text-2xl font-serif font-bold text-stone-900">
              {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.totalSpent)}
            </span>
            <span className="text-[10px] font-mono text-stone-500">
              ({stats.totalBudget > 0 ? Math.round((stats.totalSpent / stats.totalBudget) * 100) : 0}%)
            </span>
          </div>
          <div className="text-[10px] text-stone-500 font-mono flex items-center gap-1 pt-1">
            <div className="w-full bg-stone-100 h-1.5 rounded-none overflow-hidden">
              <div 
                className="bg-orange-500 h-full transition-all" 
                style={{ width: `${Math.min(100, stats.totalBudget > 0 ? (stats.totalSpent / stats.totalBudget) * 100 : 0)}%` }}
              ></div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-stone-200 p-5 space-y-2 relative overflow-hidden">
          <p className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Leads Coletados (CRM)</p>
          <div className="flex items-baseline gap-1">
            <span className="text-xl md:text-2xl font-serif font-bold text-stone-900">{stats.totalLeads}</span>
            <span className="text-[10px] font-mono text-emerald-600 font-bold flex items-center gap-0.5">
              <TrendingUp size={10} /> +15%
            </span>
          </div>
          <div className="text-[9px] text-stone-500 font-mono pt-1">
            Custo por Lead Médio: <strong className="text-stone-800">{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.avgCPL)}</strong>
          </div>
        </div>

        <div className="bg-white border border-stone-200 p-5 space-y-2 relative overflow-hidden">
          <p className="text-[10px] font-mono uppercase tracking-wider text-stone-400">Planejamento Social</p>
          <div className="flex items-baseline gap-1">
            <span className="text-xl md:text-2xl font-serif font-bold text-stone-900">{stats.scheduledPosts}</span>
            <span className="text-[10px] font-mono text-stone-400">agendados</span>
          </div>
          <div className="text-[10px] text-stone-500 font-mono flex items-center gap-1.5 pt-1">
            <span className="px-1.5 py-0.5 bg-stone-100 text-stone-600 rounded-none text-[8px] font-bold">
              {stats.publishedPosts} publicados
            </span>
          </div>
        </div>
      </div>

      {/* FILTER & TABS CONTAINER */}
      <div className="bg-stone-50 border border-stone-200 p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Sub-tabs */}
        <div className="flex gap-2">
          <button
            onClick={() => { setActiveSubTab('campanhas'); setStatusFilter('todos'); }}
            className={`px-4 py-2 text-[10px] font-mono uppercase tracking-wider font-bold border cursor-pointer transition-all ${
              activeSubTab === 'campanhas'
                ? 'bg-stone-950 border-stone-950 text-white'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            Anúncios e Campanhas
          </button>
          <button
            onClick={() => { setActiveSubTab('calendario'); setStatusFilter('todos'); }}
            className={`px-4 py-2 text-[10px] font-mono uppercase tracking-wider font-bold border cursor-pointer transition-all ${
              activeSubTab === 'calendario'
                ? 'bg-stone-950 border-stone-950 text-white'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            Calendário de Conteúdo
          </button>
          <button
            onClick={() => { setActiveSubTab('ativos'); setStatusFilter('todos'); }}
            className={`px-4 py-2 text-[10px] font-mono uppercase tracking-wider font-bold border cursor-pointer transition-all ${
              activeSubTab === 'ativos'
                ? 'bg-stone-950 border-stone-950 text-white'
                : 'bg-white border-stone-200 text-stone-600 hover:text-stone-900 hover:border-stone-300'
            }`}
          >
            Biblioteca de Ativos
          </button>
        </div>

        {/* Quick Search and Status filters */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 text-stone-400" size={14} />
            <input
              type="text"
              placeholder="Pesquisar..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white border border-stone-200 pl-9 pr-4 py-1.5 text-xs focus:outline-none focus:border-stone-400 min-w-[200px] text-stone-800 rounded-none placeholder-stone-400"
            />
          </div>

          {activeSubTab === 'campanhas' && (
            <div className="flex items-center gap-2 bg-white border border-stone-200 px-3 py-1.5 rounded-none">
              <Filter size={12} className="text-stone-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-xs bg-transparent focus:outline-none text-stone-700 font-mono font-bold cursor-pointer uppercase text-[10px]"
              >
                <option value="todos">Todos Status</option>
                <option value="planejado">Planejado</option>
                <option value="ativo">Ativo</option>
                <option value="concluido">Concluído</option>
              </select>
            </div>
          )}

          {activeSubTab === 'calendario' && (
            <div className="flex items-center gap-2 bg-white border border-stone-200 px-3 py-1.5 rounded-none">
              <Filter size={12} className="text-stone-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-xs bg-transparent focus:outline-none text-stone-700 font-mono font-bold cursor-pointer uppercase text-[10px]"
              >
                <option value="todos">Todos Status</option>
                <option value="rascunho">Rascunho</option>
                <option value="agendado">Agendado</option>
                <option value="publicado">Publicado</option>
              </select>
            </div>
          )}
        </div>
      </div>

      {/* CONTENT AREA */}
      <div>
        <AnimatePresence mode="wait">
          {/* ====================================================== */}
          {/* SUBTAB 1: CAMPANHAS */}
          {/* ====================================================== */}
          {activeSubTab === 'campanhas' && (
            <motion.div
              key="campanhas"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {filteredCampaigns.length === 0 ? (
                <div className="col-span-2 bg-white border border-stone-200 p-12 text-center text-stone-400 space-y-3">
                  <Megaphone size={36} className="mx-auto text-stone-300" />
                  <p className="text-xs">Nenhuma campanha de marketing ativa com os filtros selecionados.</p>
                  <button
                    onClick={() => handleOpenCampaignModal()}
                    className="text-[10px] font-mono uppercase tracking-wider text-orange-500 font-bold hover:underline"
                  >
                    Criar primeira campanha
                  </button>
                </div>
              ) : (
                filteredCampaigns.map((campaign) => {
                  const budgetExceeded = campaign.spent > campaign.budget;
                  const pctSpent = campaign.budget > 0 ? (campaign.spent / campaign.budget) * 100 : 0;
                  const cpl = campaign.leadsCount > 0 ? campaign.spent / campaign.leadsCount : 0;

                  return (
                    <div 
                      key={campaign.id} 
                      className="bg-white border border-stone-200 p-6 flex flex-col justify-between hover:shadow-md transition-shadow relative"
                    >
                      {/* Top platform and status */}
                      <div className="flex items-center justify-between mb-4">
                        <span className={`px-2 py-0.5 text-[9px] font-mono uppercase font-bold border ${
                          campaign.platform === 'Instagram' ? 'bg-orange-50 text-orange-700 border-orange-200' :
                          campaign.platform === 'Google Ads' ? 'bg-blue-50 text-blue-700 border-blue-200' :
                          campaign.platform === 'Pinterest' ? 'bg-red-50 text-red-700 border-red-200' :
                          campaign.platform === 'YouTube' ? 'bg-rose-50 text-rose-700 border-rose-200' :
                          'bg-stone-100 text-stone-700 border-stone-200'
                        }`}>
                          {campaign.platform}
                        </span>
                        <span className={`flex items-center gap-1 text-[9px] font-mono uppercase font-bold ${
                          campaign.status === 'ativo' ? 'text-emerald-600' :
                          campaign.status === 'planejado' ? 'text-amber-500' :
                          'text-stone-400'
                        }`}>
                          {campaign.status === 'ativo' ? <CheckCircle2 size={12} /> : <Clock size={12} />}
                          {campaign.status}
                        </span>
                      </div>

                      {/* Campaign Name & Notes */}
                      <div className="space-y-2 mb-6">
                        <h4 className="font-serif text-base text-stone-900 font-bold leading-snug">{campaign.name}</h4>
                        <p className="text-xs text-stone-500 leading-relaxed min-h-[40px] italic">
                          {campaign.notes || 'Sem anotações adicionais registradas para esta campanha.'}
                        </p>
                        <p className="text-[10px] text-stone-400 font-mono">Início: {campaign.startDate}</p>
                      </div>

                      {/* Performance Indicators */}
                      <div className="space-y-4 pt-4 border-t border-stone-100">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block">Leads Gerados</span>
                            <span className="text-base font-serif font-bold text-stone-800">{campaign.leadsCount}</span>
                          </div>
                          <div>
                            <span className="text-[9px] font-mono uppercase tracking-wider text-stone-400 block">CPL (Custo/Lead)</span>
                            <span className="text-base font-serif font-bold text-stone-800">
                              {campaign.leadsCount > 0 
                                ? new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(cpl) 
                                : 'R$ 0,00'}
                            </span>
                          </div>
                        </div>

                        {/* Budget Bar */}
                        <div className="space-y-1">
                          <div className="flex justify-between text-[10px] font-mono">
                            <span className="text-stone-500">
                              Investido: <strong>{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(campaign.spent)}</strong>
                            </span>
                            <span className="text-stone-400">
                              Orçamento: {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(campaign.budget)}
                            </span>
                          </div>
                          <div className="w-full bg-stone-100 h-2 rounded-none overflow-hidden relative">
                            <div 
                              className={`h-full transition-all ${budgetExceeded ? 'bg-red-500' : 'bg-orange-500'}`} 
                              style={{ width: `${Math.min(100, pctSpent)}%` }}
                            ></div>
                          </div>
                          {budgetExceeded && (
                            <p className="text-[8px] font-mono text-red-600 font-bold flex items-center gap-0.5">
                              <AlertCircle size={10} /> ATENÇÃO: Orçamento estourado!
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex justify-end gap-2 pt-4 mt-4 border-t border-stone-100">
                        <button
                          onClick={() => handleOpenCampaignModal(campaign)}
                          className="p-1.5 hover:bg-stone-50 text-stone-500 hover:text-stone-900 border border-stone-100 transition-all cursor-pointer"
                          title="Editar campanha"
                        >
                          <Edit size={12} />
                        </button>
                        <button
                          onClick={() => handleDeleteCampaign(campaign.id)}
                          className="p-1.5 hover:bg-red-50 text-stone-500 hover:text-red-600 border border-stone-100 hover:border-red-100 transition-all cursor-pointer"
                          title="Excluir campanha"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </motion.div>
          )}

          {/* ====================================================== */}
          {/* SUBTAB 2: CALENDARIO */}
          {/* ====================================================== */}
          {activeSubTab === 'calendario' && (
            <motion.div
              key="calendario"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              {filteredPosts.length === 0 ? (
                <div className="bg-white border border-stone-200 p-12 text-center text-stone-400 space-y-3">
                  <Calendar size={36} className="mx-auto text-stone-300" />
                  <p className="text-xs">Nenhuma publicação agendada ou rascunho com o filtro selecionado.</p>
                  <button
                    onClick={() => handleOpenPostModal()}
                    className="text-[10px] font-mono uppercase tracking-wider text-orange-500 font-bold hover:underline"
                  >
                    Agendar primeira publicação
                  </button>
                </div>
              ) : (
                <div className="bg-white border border-stone-200 rounded-none overflow-hidden">
                  <div className="p-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-stone-400 font-bold">CRONOGRAMA DE POSTAGENS</span>
                    <span className="text-[9px] font-mono text-stone-500">Visualização de Cronograma Linear</span>
                  </div>
                  <div className="divide-y divide-stone-100">
                    {filteredPosts.map((post) => (
                      <div key={post.id} className="p-5 flex flex-col md:flex-row md:items-start justify-between gap-4 hover:bg-stone-50 transition-colors">
                        <div className="flex gap-4 items-start">
                          <div className={`p-2.5 rounded-none flex-shrink-0 ${
                            post.platform === 'Instagram' ? 'bg-orange-50 text-orange-600 border border-orange-100' :
                            post.platform === 'Pinterest' ? 'bg-red-50 text-red-600 border border-red-100' :
                            post.platform === 'LinkedIn' ? 'bg-blue-50 text-blue-600 border border-blue-100' :
                            post.platform === 'YouTube' ? 'bg-rose-50 text-rose-600 border border-rose-100' :
                            'bg-stone-100 text-stone-600 border border-stone-200'
                          }`}>
                            <Instagram size={18} />
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h5 className="font-serif text-sm font-bold text-stone-900">{post.title}</h5>
                              <span className={`px-1.5 py-0.5 text-[8px] font-mono uppercase font-bold border ${
                                post.status === 'publicado' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                                post.status === 'agendado' ? 'bg-purple-50 text-purple-700 border-purple-200' :
                                'bg-stone-100 text-stone-600 border-stone-300'
                              }`}>
                                {post.status}
                              </span>
                            </div>
                            <p className="text-xs text-stone-500 font-mono">Plataforma: {post.platform} • Data de Envio: {post.publishDate}</p>
                            <p className="text-xs text-stone-600 leading-relaxed bg-stone-50 p-3 border border-stone-100 font-sans mt-2 italic whitespace-pre-wrap">
                              "{post.caption || 'Sem legenda ou texto de copy cadastrado para esta publicação.'}"
                            </p>
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex md:flex-col justify-end gap-2 self-end md:self-start flex-shrink-0 pt-2">
                          <button
                            onClick={() => handleOpenPostModal(post)}
                            className="p-1.5 hover:bg-white text-stone-500 hover:text-stone-900 border border-stone-200 transition-all cursor-pointer flex items-center gap-1 text-[10px] font-mono uppercase font-bold"
                          >
                            <Edit size={12} /> Editar
                          </button>
                          <button
                            onClick={() => handleDeletePost(post.id)}
                            className="p-1.5 hover:bg-red-50 text-stone-500 hover:text-red-600 border border-stone-200 hover:border-red-200 transition-all cursor-pointer flex items-center gap-1 text-[10px] font-mono uppercase font-bold"
                          >
                            <Trash2 size={12} /> Excluir
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* ====================================================== */}
          {/* SUBTAB 3: ATIVOS DE MARCA */}
          {/* ====================================================== */}
          {activeSubTab === 'ativos' && (
            <motion.div
              key="ativos"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
            >
              {filteredAssets.length === 0 ? (
                <div className="col-span-2 bg-white border border-stone-200 p-12 text-center text-stone-400 space-y-3">
                  <FileText size={36} className="mx-auto text-stone-300" />
                  <p className="text-xs">Nenhum ativo de marca encontrado.</p>
                  <button
                    onClick={() => handleOpenAssetModal()}
                    className="text-[10px] font-mono uppercase tracking-wider text-orange-500 font-bold hover:underline"
                  >
                    Cadastrar primeiro ativo
                  </button>
                </div>
              ) : (
                filteredAssets.map((asset) => (
                  <div key={asset.id} className="bg-white border border-stone-200 p-5 flex flex-col justify-between hover:shadow-sm transition-shadow">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <span className="px-2 py-0.5 bg-stone-100 border border-stone-200 text-stone-700 text-[9px] font-mono uppercase font-bold">
                          {asset.type}
                        </span>
                        <span className="text-[10px] font-mono text-stone-400 font-bold">{asset.size}</span>
                      </div>
                      <h4 className="font-serif text-base text-stone-900 font-bold tracking-tight">{asset.name}</h4>
                      <p className="text-xs text-stone-500 leading-relaxed font-sans">{asset.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-5 mt-5 border-t border-stone-100">
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleCopyLink(asset.id, asset.link)}
                          className="px-3 py-1.5 border border-stone-200 hover:bg-stone-50 text-stone-600 hover:text-stone-900 text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer flex items-center gap-1"
                        >
                          {copiedId === asset.id ? <Check size={12} className="text-emerald-600" /> : <Copy size={12} />}
                          {copiedId === asset.id ? 'Copiado!' : 'Copiar Link'}
                        </button>
                        <a
                          href={asset.link}
                          target="_blank"
                          referrerPolicy="no-referrer"
                          rel="noreferrer"
                          className="px-3 py-1.5 border border-stone-200 hover:bg-stone-50 text-stone-600 hover:text-stone-900 text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer flex items-center gap-1"
                        >
                          <ExternalLink size={12} /> Acessar
                        </a>
                      </div>

                      <div className="flex gap-1">
                        <button
                          onClick={() => handleOpenAssetModal(asset)}
                          className="p-1.5 hover:bg-stone-50 text-stone-400 hover:text-stone-900 transition-all cursor-pointer"
                          title="Editar"
                        >
                          <Edit size={12} />
                        </button>
                        <button
                          onClick={() => handleDeleteAsset(asset.id)}
                          className="p-1.5 hover:bg-red-50 text-stone-400 hover:text-red-600 transition-all cursor-pointer"
                          title="Excluir"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ====================================================== */}
      {/* MODAL: CAMPANHA */}
      {/* ====================================================== */}
      {isCampaignModalOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-stone-200 max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h3 className="font-serif text-lg text-stone-900 font-bold border-b border-stone-100 pb-3">
              {editingCampaign ? 'Editar Campanha de Marketing' : 'Cadastrar Nova Campanha'}
            </h3>
            <form onSubmit={handleSaveCampaign} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Nome da Campanha</label>
                <input
                  type="text"
                  required
                  value={campaignForm.name}
                  onChange={(e) => setCampaignForm({ ...campaignForm, name: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  placeholder="Ex: Instagram Alto Padrão - Verão 2026"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Plataforma / Canal</label>
                  <select
                    value={campaignForm.platform}
                    onChange={(e) => setCampaignForm({ ...campaignForm, platform: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 cursor-pointer"
                  >
                    <option value="Instagram">Instagram</option>
                    <option value="Google Ads">Google Ads</option>
                    <option value="Pinterest">Pinterest</option>
                    <option value="YouTube">YouTube</option>
                    <option value="LinkedIn">LinkedIn</option>
                    <option value="Outro">Outro</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Status</label>
                  <select
                    value={campaignForm.status}
                    onChange={(e) => setCampaignForm({ ...campaignForm, status: e.target.value as any })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 cursor-pointer"
                  >
                    <option value="planejado">Planejado</option>
                    <option value="ativo">Ativo</option>
                    <option value="concluido">Concluído</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Orçamento (R$)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={campaignForm.budget}
                    onChange={(e) => setCampaignForm({ ...campaignForm, budget: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Investido (R$)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={campaignForm.spent}
                    onChange={(e) => setCampaignForm({ ...campaignForm, spent: parseFloat(e.target.value) || 0 })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Leads Coletados</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={campaignForm.leadsCount}
                    onChange={(e) => setCampaignForm({ ...campaignForm, leadsCount: parseInt(e.target.value) || 0 })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Data de Início</label>
                <input
                  type="date"
                  required
                  value={campaignForm.startDate}
                  onChange={(e) => setCampaignForm({ ...campaignForm, startDate: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Anotações / Estratégia</label>
                <textarea
                  value={campaignForm.notes}
                  onChange={(e) => setCampaignForm({ ...campaignForm, notes: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 min-h-[80px]"
                  placeholder="Ex: Foco em depoimento de clientes sobre reformas completas."
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 font-mono text-[10px] uppercase font-bold border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsCampaignModalOpen(false)}
                  className="bg-stone-100 hover:bg-stone-200 text-stone-700 px-4 py-2 border border-stone-300 cursor-pointer transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-stone-900 hover:bg-stone-800 text-white px-4 py-2 border border-stone-900 cursor-pointer transition-all"
                >
                  Salvar Campanha
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================== */}
      {/* MODAL: PUBLICACAO */}
      {/* ====================================================== */}
      {isPostModalOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-stone-200 max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h3 className="font-serif text-lg text-stone-900 font-bold border-b border-stone-100 pb-3">
              {editingPost ? 'Editar Publicação Agendada' : 'Agendar Nova Publicação'}
            </h3>
            <form onSubmit={handleSavePost} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Título do Conteúdo</label>
                <input
                  type="text"
                  required
                  value={postForm.title}
                  onChange={(e) => setPostForm({ ...postForm, title: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  placeholder="Ex: Visita Técnica Obra Barra da Tijuca"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Plataforma</label>
                  <select
                    value={postForm.platform}
                    onChange={(e) => setPostForm({ ...postForm, platform: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 cursor-pointer"
                  >
                    <option value="Instagram">Instagram</option>
                    <option value="Pinterest">Pinterest</option>
                    <option value="LinkedIn">LinkedIn</option>
                    <option value="YouTube">YouTube</option>
                    <option value="Site">Site CBC</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Status</label>
                  <select
                    value={postForm.status}
                    onChange={(e) => setPostForm({ ...postForm, status: e.target.value as any })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 cursor-pointer"
                  >
                    <option value="rascunho">Rascunho</option>
                    <option value="agendado">Agendado</option>
                    <option value="publicado">Publicado</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Data de Publicação</label>
                <input
                  type="date"
                  required
                  value={postForm.publishDate}
                  onChange={(e) => setPostForm({ ...postForm, publishDate: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Legenda / Copy / Roteiro</label>
                <textarea
                  value={postForm.caption}
                  onChange={(e) => setPostForm({ ...postForm, caption: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 min-h-[120px] font-mono"
                  placeholder="Digite aqui todo o texto da postagem..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 font-mono text-[10px] uppercase font-bold border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsPostModalOpen(false)}
                  className="bg-stone-100 hover:bg-stone-200 text-stone-700 px-4 py-2 border border-stone-300 cursor-pointer transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-stone-900 hover:bg-stone-800 text-white px-4 py-2 border border-stone-900 cursor-pointer transition-all"
                >
                  Agendar Publicação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ====================================================== */}
      {/* MODAL: ATIVO DE MARCA */}
      {/* ====================================================== */}
      {isAssetModalOpen && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
          <div className="bg-white border border-stone-200 max-w-lg w-full p-6 space-y-4 shadow-xl">
            <h3 className="font-serif text-lg text-stone-900 font-bold border-b border-stone-100 pb-3">
              {editingAsset ? 'Editar Ativo de Marca' : 'Adicionar Ativo de Marca'}
            </h3>
            <form onSubmit={handleSaveAsset} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Nome do Recurso</label>
                <input
                  type="text"
                  required
                  value={assetForm.name}
                  onChange={(e) => setAssetForm({ ...assetForm, name: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  placeholder="Ex: Logotipo Oficial Chaves Brites - Vetorizado"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Tipo de Recurso</label>
                  <select
                    value={assetForm.type}
                    onChange={(e) => setAssetForm({ ...assetForm, type: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 cursor-pointer"
                  >
                    <option value="Documento (PDF)">Documento (PDF)</option>
                    <option value="Vetor / Imagem (SVG, PNG)">Vetor / Imagem (SVG, PNG)</option>
                    <option value="Apresentação (PPTX)">Apresentação (PPTX)</option>
                    <option value="Modelo (Canva)">Modelo (Canva)</option>
                    <option value="Vídeo (MP4)">Vídeo (MP4)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Tamanho aproximado</label>
                  <input
                    type="text"
                    required
                    value={assetForm.size}
                    onChange={(e) => setAssetForm({ ...assetForm, size: e.target.value })}
                    className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                    placeholder="Ex: 4.5 MB"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Link de Acesso ou Download</label>
                <input
                  type="url"
                  required
                  value={assetForm.link}
                  onChange={(e) => setAssetForm({ ...assetForm, link: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800"
                  placeholder="https://..."
                />
              </div>

              <div className="space-y-1">
                <label className="block text-[10px] font-mono uppercase tracking-wider text-stone-500 font-bold">Descrição do Ativo</label>
                <textarea
                  required
                  value={assetForm.description}
                  onChange={(e) => setAssetForm({ ...assetForm, description: e.target.value })}
                  className="w-full bg-stone-50 border border-stone-200 p-2.5 focus:outline-none focus:border-stone-400 text-stone-800 min-h-[80px]"
                  placeholder="Ex: Manual de uso da marca contendo paleta de cores institucional..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 font-mono text-[10px] uppercase font-bold border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsAssetModalOpen(false)}
                  className="bg-stone-100 hover:bg-stone-200 text-stone-700 px-4 py-2 border border-stone-300 cursor-pointer transition-all"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-stone-900 hover:bg-stone-800 text-white px-4 py-2 border border-stone-900 cursor-pointer transition-all"
                >
                  Salvar Ativo
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
