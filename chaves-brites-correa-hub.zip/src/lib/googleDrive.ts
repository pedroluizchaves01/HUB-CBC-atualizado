/**
 * Helper utilities for interacting with the Google Drive API client-side.
 */

interface DriveFile {
  id: string;
  name: string;
  webViewLink?: string;
}

interface DriveListResponse {
  files: DriveFile[];
}

/**
 * Searches for a folder by name in the user's Google Drive. If not found, creates it.
 */
export async function findOrCreateFolder(accessToken: string, folderName: string): Promise<string> {
  if (accessToken === 'mock_google_access_token_cbc_123' || accessToken.startsWith('mock_') || accessToken.startsWith('manual_connected_token_')) {
    console.log('[Google Drive Mock] Using mock token. Mocking findOrCreateFolder.');
    return 'mock_google_drive_folder_id_123';
  }

  try {
    // 1. Search for the folder
    const q = `name = '${folderName.replace(/'/g, "\\'")}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
    const searchUrl = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name)`;
    
    const searchRes = await fetch(searchUrl, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!searchRes.ok) {
      const errorText = await searchRes.text();
      throw new Error(`Erro ao buscar pasta no Google Drive: ${errorText}`);
    }

    const searchData: DriveListResponse = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      return searchData.files[0].id;
    }

    // 2. Folder does not exist, create it
    const createRes = await fetch('https://www.googleapis.com/drive/v3/files?fields=id', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: folderName,
        mimeType: 'application/vnd.google-apps.folder',
      }),
    });

    if (!createRes.ok) {
      const errorText = await createRes.text();
      throw new Error(`Erro ao criar pasta no Google Drive: ${errorText}`);
    }

    const createData = await createRes.json();
    return createData.id;
  } catch (error: any) {
    console.error('Erro em findOrCreateFolder:', error);
    throw error;
  }
}

/**
 * Uploads a file (PDF or image) in base64 format to a specific Google Drive folder.
 * Returns the file ID and direct webViewLink.
 */
export async function uploadFileToFolder(
  accessToken: string,
  folderId: string,
  fileName: string,
  fileMimeType: string,
  base64Data: string
): Promise<{ id: string; webViewLink: string }> {
  if (accessToken === 'mock_google_access_token_cbc_123' || accessToken.startsWith('mock_') || accessToken.startsWith('manual_connected_token_')) {
    console.log('[Google Drive Mock] Using mock token. Mocking uploadFileToFolder.');
    return {
      id: `mock_file_${Math.random().toString(36).substring(2, 11)}`,
      webViewLink: 'https://drive.google.com/drive/folders/mock_google_drive_folder_id_123',
    };
  }

  try {
    const boundary = 'cbc_drive_upload_boundary_1234567890';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelim = `\r\n--${boundary}--`;

    const metadata = {
      name: fileName,
      mimeType: fileMimeType,
      parents: [folderId],
    };

    // Clean up base64 prefix if present (e.g. "data:image/png;base64,...")
    let cleanBase64 = base64Data;
    if (base64Data.includes(';base64,')) {
      cleanBase64 = base64Data.split(';base64,')[1];
    }

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: ' + fileMimeType + '\r\n' +
      'Content-Transfer-Encoding: base64\r\n\r\n' +
      cleanBase64 +
      closeDelim;

    const uploadUrl = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink';
    
    const response = await fetch(uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartRequestBody,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Erro ao carregar arquivo no Google Drive: ${errorText}`);
    }

    const data = await response.json();
    return {
      id: data.id,
      webViewLink: data.webViewLink || `https://drive.google.com/file/d/${data.id}/view`,
    };
  } catch (error: any) {
    console.error('Erro em uploadFileToFolder:', error);
    throw error;
  }
}
